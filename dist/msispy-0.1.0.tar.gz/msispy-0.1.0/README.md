NRL Mass Spectrometer and Incoherent Scatter Radar 2000 (NRLMSISE-00)
==========================================================
----------------------------------------------------------

This model is maintained and developed by the Naval Research Laboratory, Space Science Division. Please visit 
<http://www.nrl.navy.mil/research/nrl-review/2003/atmospheric-science/picone/>

**SuperDARN's contribution consists of Python wrappers to this model. This contribution is covered under DaViTpy license.**
